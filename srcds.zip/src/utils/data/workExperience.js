export const experiencesData = [
  {
    position: "Self-Employed",
    company: "Self",
    year: "Jan 2022 - Present",
    description:
      "Worked on various projects, built websites, and learned new technologies.",
  },
  {
    position: "PHP Software Developer",
    company: "Infinite Open Source Solutions LLP",
    year: "Aug 2017 - Nov 2021",
    description:
      "Developing MLM softwares, E-commerce websites and integrating payment gateways",
  },
  
];