export const myEducationData = [
  {
    school: "Canara Engineering College, Mangaluru",
    degree: "Bachelor of Engineering in Computer Science",
    year: "August 2012 - October 2016",
    description: "",
  },

];