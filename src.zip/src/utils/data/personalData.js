export const personalData = {
  name: "Rajat P Rao",
  role: "Software Developer",
  phone: "(+91) 9008765026",
  email: "balprao@gmail.com",
  location: "Kanhangad, Kerala",
  resume: "https://drive.google.com/file/d/1n7ufitYEyjEMioQexUrCO8VDmwOSEfjC/view?usp=sharing",
};
